# titrationSimulator
A protein interaction NMR study computer practical suitable for the classroom
