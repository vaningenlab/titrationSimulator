% saveState.m

disp("")
disp("Saving the titration into \"state.out\" ...")
save "state.out"
disp("Done!")
disp("You can now quit the program with \"exit\" and restart later.")
disp("")
